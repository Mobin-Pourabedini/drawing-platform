export enum ShapeTypes {
    Triangle = 'triangle',
    Square = 'square',
    Circle = 'circle',
}
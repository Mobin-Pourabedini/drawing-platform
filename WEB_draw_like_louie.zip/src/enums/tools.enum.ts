export enum Tools {
    Pen = 'pen',
    Triangle = 'triangle',
    Square = 'square',
    Circle = 'circle',
}

/// <reference enums="vite/client" />
